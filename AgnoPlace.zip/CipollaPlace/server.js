const cors = require('cors');
const express = require('express');
const Redis = require('ioredis');
const socketio = require('socket.io');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketio(server);
const port = 3000;

const client = new Redis({
  host: 'localhost',
  port: 6379,
});

client.on('connect', () => {
  console.log('Connected to Redis');
});

client.on('error', (err) => {
  console.log('Redis error: ' + err);
});

app.use(cors());
app.use(express.static('public'));

app.get('/pixels', (req, res) => {
  console.log("Getting all pixels...");
  getAllPixels((err, pixels) => {
    if (err) return res.status(500).send('Error retrieving pixels');
    console.log("Got all pixels!");
    res.status(200).json(pixels);
  });
});

app.post('/pixel', express.json(), (req, res) => {
  const { x, y, color } = req.body;
  savePixel(x, y, color);
  io.emit('pixelChange', { x, y, color });
  res.status(200).send('Pixel saved');
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);

  socket.on('pixel', (data) => {
    const { x, y, color } = data;
    savePixel(x, y, color);
    io.emit('pixelChange', { x, y, color }); // Informa tutti gli altri client
  });
});

server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

function savePixel(x, y, color) {
  console.log(`Saving pixel at ${x}:${y} with color ${color}`);
  const key = `${x}:${y}`;
  client.set(key, color, (err) => {
    if (err) {
      console.error('Error saving pixel:', err);
    } else {
      console.log(`Pixel saved at ${key} with color ${color}`);
    }
  });
}

function getAllPixels(callback) {
  client.keys('*').then(keys => {
    if (keys.length === 0) {
      console.log("No keys found.");
      return callback(null, {});
    }
    client.mget(...keys).then(values => {
      const pixels = {};
      keys.forEach((key, index) => {
        pixels[key] = values[index];
      });
      console.log("Pixels retrieved:", pixels);
      callback(null, pixels);
    }).catch(err => {
      console.error("Error fetching values:", err);
      callback(err);
    });
  }).catch(err => {
    console.error("Error fetching keys:", err);
    callback(err);
  });
}
